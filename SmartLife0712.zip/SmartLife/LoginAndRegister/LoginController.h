//
//  LoginController.h
//  SmartLife
//
//  Created by zppro on 12-11-24.
//  Copyright (c) 2012年 zppro. All rights reserved.
//

#import "AppBaseController.h"

@interface LoginController : AppBaseController<UITextFieldDelegate, CInputAssistViewDelgate> 



@end
