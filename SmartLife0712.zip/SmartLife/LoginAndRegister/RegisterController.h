//
//  RegisterController.h
//  SmartLife
//
//  Created by zppro on 13-3-21.
//  Copyright (c) 2013年 zppro. All rights reserved.
//

#import "AppBaseController.h"

@interface RegisterController : AppBaseController<UITextFieldDelegate,CInputAssistViewDelgate>

@end
