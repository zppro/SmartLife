//
//  SmartControlIndexController.h
//  SmartLife
//
//  Created by zppro on 13-3-22.
//  Copyright (c) 2013年 zppro. All rights reserved.
//

#import "AppBaseController.h"

@interface SmartControlIndexController : AppBaseController<TileDelegate, TileWallDelegate>

@end
