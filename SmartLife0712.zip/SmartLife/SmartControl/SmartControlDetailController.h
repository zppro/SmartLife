//
//  SmartControlDetailController.h
//  SmartLife
//
//  Created by zppro on 13-3-22.
//  Copyright (c) 2013年 zppro. All rights reserved.
//

#import "AppBaseController.h"
@class CDevice;

@interface SmartControlDetailController : AppBaseController

-(id)initWithDevice:(CDevice*)aDevice;

@end
