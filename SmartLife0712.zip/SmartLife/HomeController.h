//
//  HomeController.h
//  SmartLife
//
//  Created by zppro on 12-11-20.
//  Copyright (c) 2012年 zppro. All rights reserved.
//

#import "AppBaseController.h"

@interface HomeController : AppBaseController<CLLocationManagerDelegate>{
    MBProgressHUD *HUD;
}

@end
