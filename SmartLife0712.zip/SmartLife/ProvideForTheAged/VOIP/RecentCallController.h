//
//  RecentCallController.h
//  SmartLife
//
//  Created by zppro on 12-12-3.
//  Copyright (c) 2012年 zppro. All rights reserved.
//

#import "AppBaseController.h"

@interface RecentCallController : AppBaseController<UITableViewDelegate, UITableViewDataSource>

@end
