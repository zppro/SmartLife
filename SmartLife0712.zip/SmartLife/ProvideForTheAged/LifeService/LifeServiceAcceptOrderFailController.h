//
//  LifeServiceAcceptOrderFailController.h
//  SmartLife
//
//  Created by zppro on 12-12-4.
//  Copyright (c) 2012年 zppro. All rights reserved.
//

#import "AppBaseController.h"

@interface LifeServiceAcceptOrderFailController : AppBaseController<TableHeaderDelegate>

@end
