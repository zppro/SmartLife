//
//  LifeServiceAcceptOrderProcessController.h
//  SmartLife
//
//  Created by zppro on 12-12-4.
//  Copyright (c) 2012年 zppro. All rights reserved.
//

#import "AppBaseController.h"

@interface LifeServiceAcceptOrderProcessController : AppBaseController<TableHeaderDelegate,UITableViewDelegate, UITableViewDataSource,UIScrollViewDelegate,DDPageControlDelegate>

@end
