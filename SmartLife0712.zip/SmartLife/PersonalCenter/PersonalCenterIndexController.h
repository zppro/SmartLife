//
//  PersonalCenterIndexController.h
//  SmartLife
//
//  Created by zppro on 13-1-1.
//  Copyright (c) 2013年 zppro. All rights reserved.
//

#import "AppBaseController.h"

@interface PersonalCenterIndexController : AppBaseController

@end
