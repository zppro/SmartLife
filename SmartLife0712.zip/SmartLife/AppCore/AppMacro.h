//
//  AppMacro.h
//  SmartLife
//
//  Created by zppro on 12-12-18.
//  Copyright (c) 2012年 zppro. All rights reserved.
//

#ifndef SmartLife_AppMacro_h
#define SmartLife_AppMacro_h

#define baseURL  @"http://www.lifeblue.com.cn/WebService/Default.ashx"
#define baseURL2 @"http://www.lifeblue.com.cn/WebService/Upload.ashx"
#define baseURL3 @"www.lifeblue.com.cn/WebService/Upload/CallService" 
#define nwCode(x) [appSession getNWCode:x]
#define localSoundDir JOINP(MF_DocumentFolder(),@"sound")

#endif
