//
//  GlobalObjectsContainer.m
//  iWedding
//
//  Created by 钟 平 on 12-7-4.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import "GlobalObjectsContainer.h"

@implementation GlobalObjectsContainer
SYNTHESIZE_LESSER_SINGLETON_FOR_CLASS(GlobalObjectsContainer); 
@end
